import uuid


class User:

    username = ""
    email = ""
    guid = str(uuid.uuid4())
