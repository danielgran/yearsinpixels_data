from abc import ABC


class Entity(ABC):
    pass
